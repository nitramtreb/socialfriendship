<?php
$db_conx = mysqli_connect("127.0.0.1", "frie_user", "DSASEWS5467", "frei_friends");
// Evaluate the connection
if (mysqli_connect_errno()) {
    echo mysqli_connect_error();
    exit();
} else {
	echo "";
}
?>