<?php
include_once("../includes/check_login_status.php");
if($user_ok != true || $log_username == "") {
	exit();
}
?>

<?php
$users_list = "";
$sql = "SELECT * FROM users WHERE username LIKE BINARY '$log_username' ORDER BY date_time DESC";
$query = mysqli_query($db_conx, $sql);
$numrows = mysqli_num_rows($query);

?>