window.onerror = function(msg, url, lineNo, columnNo, error) {
  // ... handle error ...
  return false;
}